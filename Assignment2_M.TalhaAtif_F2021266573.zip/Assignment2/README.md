# replicating_a_web
I've replicated https://gartechintl.com/